<?php $__env->startSection('content'); ?>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" style="text/css">
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" style="text/css">


<div class="container">
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Tujuan</th>
                <th>Nama Devisi</th>
                <th>User Pengirim</th>
                <th>Pesan</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $saran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($item->tujuan); ?></td>
            <td><?php echo e($item->nama_tujuan); ?></td>
            <td><?php echo e($item->user); ?></td>
            <td><?php echo e($item->pesan); ?></td>
          
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
         
        </tbody>
        <tfoot>
            <tr>
                <th>Tujuan</th>
                <th>Nama Devisi</th>
                <th>User Pengirim</th>
                <th>Pesan</th>
                
            </tr>
        </tfoot>
    </table>
    
</div>

<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/project/saran/resources/views/saran/data.blade.php ENDPATH**/ ?>